import 'package:flutter/material.dart';

class KotGen extends StatefulWidget {
  @override
  _KotGenState createState() => _KotGenState();
}

class _KotGenState extends State<KotGen> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
